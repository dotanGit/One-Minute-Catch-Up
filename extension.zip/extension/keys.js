export const keys = {
    apiKey: "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",
};